/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import business.Constants;
import static business.Constants.x_coord;
import static business.Constants.y_coord;
import business.Dijkstra;
import business.Edge;
import business.Particle;
import business.Swarm;
import business.Vertex;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.util.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JLabel;
import static userInterface.MainFrame.draw2;

/**
 *
 * @author kahma
 */
public class AreaMapJPanel extends javax.swing.JPanel {

    /**
     * Creates new form AreaMapJPanel
     */
    int eventPointX, eventPointY;
    Swarm swarm;
    double[][] areaMap;
    int temp1, temp2;
    BufferedImage img2;
    BufferedImage image;
    double minDistToEvent = 1000;
    int minx_coord = 0;
    int miny_coord = 0;
    int nearestStation;
    private static Random r = new Random();
    int filenum = r.nextInt(30);
    Particle p;
    JLabel jLabe1;
    MainFrame PSO;
    Graphics g;
    Vertex v;
    int x, y;

    public static List<Edge> path;

    double distToEvent;
    int[] coord = new int[30];
    Map<Integer, Double> min_distance = new HashMap<Integer, Double>();
    Map<Integer, Integer[]> vertexMap = new HashMap<Integer, Integer[]>();
//    File file = new File("/Users/saheb/Downloads/New Pso is here/ParticleSwarmOptimization-master/src/Files/Station.txt");
//    File file2 = new File("/Users/saheb/Downloads/New Pso is here/ParticleSwarmOptimization-master/src/Files/StationPairs.txt");

    File file;
    File file2;
//      String filePath = "/Users/saheb/Downloads/New Pso is here/ParticleSwarmOptimization-master/src/Files";
    String filePath = "C:\\Users\\kahma\\OneDrive\\Desktop";
    String fileName = "Station"+filenum+".txt";

    String fileName2 = "StationPairs"+filenum+".txt";
    
    
    
    public void fileCreate()
    {
        file = new File(filePath+"\\"+fileName);
        file2 = new File(filePath+"\\"+fileName2);
    }
    public AreaMapJPanel(int eventPointX, int eventPointY, Swarm swarm, double[][] areaMap) {

        initComponents();
        this.eventPointX = eventPointX;
        this.eventPointY = eventPointY;
        this.swarm = swarm;
        this.areaMap = areaMap;

    }

    public void fillImage(Graphics g, int x, int y, int size) throws IOException {
//        img2 = ImageIO.read(new File("/Users/saheb/Downloads/New Pso is here/ParticleSwarmOptimization-master/src/userInterface/T station.jpeg"));
        img2 = ImageIO.read(new File("C:\\Users\\kahma\\OneDrive\\Desktop\\timage.jpg"));
        Image img3 = resize(img2, 32, 32);

        g.drawImage(img3, x - size / 2, y - size / 2, this);
    }

    private static BufferedImage resize(BufferedImage img, int height, int width) {
        Image tmp = img.getScaledInstance(width, height, Image.SCALE_SMOOTH);
        BufferedImage resized = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = resized.createGraphics();
        g2d.drawImage(tmp, 0, 0, null);
        g2d.dispose();
        return resized;
    }

    public void fillImage2(Graphics g, int x, int y, int size) throws IOException {
//        BufferedImage boston_event = ImageIO.read(new File("/Users/saheb/Downloads/New Pso is here/ParticleSwarmOptimization-master/src/userInterface/Red Sox.jpeg"));
        BufferedImage boston_event = ImageIO.read(new File("C:\\Users\\kahma\\OneDrive\\Desktop\\red-sox.png"));
        Image img3 = resize(boston_event, 50, 50);
        g.drawImage(img3, x - size / 2, y - size / 2, this);
    }

    @Override
    public void paint(Graphics g) {

        Graphics2D g2 = (Graphics2D) g;

//        g.drawImage(new ImageIcon("/Users/saheb/Downloads/New Pso is here/ParticleSwarmOptimization-master/src/userInterface/Boston Map.png").getImage(), 0, 0, null);
        g.drawImage(new ImageIcon("C:\\Users\\kahma\\OneDrive\\Desktop\\Boston Map.png").getImage(), 0, 0, null);
        // Paint Swarm particles

        for (Particle p : swarm.getParticles()) {
            g.setColor(Color.BLUE);
            g.fillOval(p.getxPos() * Constants.MULTIPLICATION_FACTOR, p.getyPos() * Constants.MULTIPLICATION_FACTOR, 10, 10);
        }

        BufferedWriter bw = null;
        BufferedWriter bw2 = null;

        try {
            fileCreate();
            FileWriter bstream = new FileWriter(file);
            bw = new BufferedWriter(bstream);
            FileWriter bstream1 = new FileWriter(file2);
            bw2 = new BufferedWriter(bstream1);

            bw2.write(String.valueOf("Event_Location" + "," + PSO.eventX + "," + PSO.eventY));
            bw2.newLine();
            for (int i = 0; i < Constants.TOTAL_TStations; i++) {

                g.setColor(Color.RED);
                g.setFont(new Font("TimesRoman", Font.BOLD, 15));
                g.drawString("Station " + i + " " + "(" + x_coord[i] + "," + y_coord[i] + ")", x_coord[i] * 5, y_coord[i] * 5);
                g.fillOval(x_coord[i] * 5, y_coord[i] * 5, 20, 20);
                g.setColor(Color.GRAY);
                if (i != 0) {
                    g.drawLine(temp1 * 5, temp2 * 5, x_coord[i] * 5, y_coord[i] * 5);
                }
                g2.setStroke(new BasicStroke(4));

                fillImage(g, x_coord[i] * 5, y_coord[i] * 5, 15);

                distToEvent = Math.sqrt((PSO.eventX - x_coord[i]) * (PSO.eventX - x_coord[i]) + (PSO.eventY - y_coord[i]) * (PSO.eventY - y_coord[i]));
                System.out.println("Event :" + PSO.eventX + " " + PSO.eventY);
                if (distToEvent < minDistToEvent) {
                    nearestStation = i;
                    minDistToEvent = distToEvent;
                    minx_coord = x_coord[i];
                    miny_coord = y_coord[i];

                }

                min_distance.put(i, distToEvent);
                System.out.println("Min Distance " + x_coord[i] + "," + y_coord[i] + " " + min_distance.get(i));
                Double min = Collections.min(min_distance.values());
                System.out.println(min);
                temp1 = x_coord[i];
                temp2 = y_coord[i];
//                

                if (i < Constants.TOTAL_TStations - 1) {
                    bw.write(String.valueOf("Station_" + Integer.toString(i) + "," + "Station_" + Integer.toString(i + 1) + "," + 100));
                    bw.newLine();
                }
                if (i < Constants.TOTAL_TStations) {
                    bw2.write(String.valueOf("Station_" + i + "," + x_coord[i] + "," + y_coord[i]));
                    bw2.newLine();
                }

            }
            
//            System.out.println("Sorted Map");
            Map sortedMap = sortByValue(min_distance);
//            System.out.println(sortedMap);

        } catch (IOException ex) {
            Logger.getLogger(AreaMapJPanel.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (bw != null) {
                try {
                    bw.close();
                } catch (IOException ex) {
                    Logger.getLogger(AreaMapJPanel.class.getName()).log(Level.SEVERE, null, ex);
                }

                if (bw2 != null) {
                    try {
                        bw2.close();
                    } catch (IOException ex) {
                        Logger.getLogger(AreaMapJPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            }

            try {
                minEdge(g, nearestStation);
            } catch (IOException ex) {
                Logger.getLogger(AreaMapJPanel.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            if(Constants.flag==true) {
                
                try{
                draw2(g);
                }
                catch (Exception e) {
                System.out.println("No shortest Path found.");
            }
            } else {
                
            }

        }

    }

    public List<Edge> sourceToDest(String a, String b) throws FileNotFoundException, IOException {

        Dijkstra dijkstra = new Dijkstra();

        String line;

        BufferedReader vertexFileBr;
        try {
            vertexFileBr = new BufferedReader(new FileReader(file2));
            while ((line = vertexFileBr.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 3) {
                    vertexFileBr.close();
                    throw new IOException("Invalid line in vertex file " + line);
                }
                String cityname = parts[0];
                int x = Integer.valueOf(parts[1]);
                int y = Integer.valueOf(parts[2]);
                Vertex vertex = new Vertex(cityname, x, y);
                dijkstra.addVertex(vertex);
            }
            vertexFileBr.close();

            BufferedReader edgeFileBr = new BufferedReader(new FileReader(file));
            while ((line = edgeFileBr.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length != 3) {
                    edgeFileBr.close();
                    throw new IOException("Invalid line in edge file " + line);
                }
                dijkstra.addUndirectedEdge(parts[0], parts[1], Double.parseDouble(parts[2]));
            }
            edgeFileBr.close();

            // print out an adjacency list representation of the graph
        } catch (FileNotFoundException ex) {
            Logger.getLogger(AreaMapJPanel.class.getName()).log(Level.SEVERE, null, ex);
        }

        dijkstra.printAdjacencyList();
        path = dijkstra.getDijkstraPath(a, b);

        System.out.println("Path" + path);

        
        return path;

    }



    public void minEdge(Graphics g, int x) throws IOException {
        BufferedWriter out = null;
        try {
            FileWriter fstream = new FileWriter(file, true); //true tells to append data.
            out = new BufferedWriter(fstream);
            out.write(String.valueOf("Event_Location" + "," + "Station_" + x + "," + 100));
        } catch (IOException e) {
            System.err.println("Error: " + e.getMessage());
        } finally {
            if (out != null) {
                out.close();
            }
        }


        System.out.println("XCORD " + minx_coord + " YCOORD " + miny_coord);
        if (minx_coord != 0 && miny_coord != 0) {
            g.setColor(Color.RED);
            g.setFont(new Font("TimesRoman", Font.BOLD, 20));
            g.drawString("Event Location ", PSO.eventX * Constants.MULTIPLICATION_FACTOR, PSO.eventY * Constants.MULTIPLICATION_FACTOR);
            g.fillOval(PSO.eventX * Constants.MULTIPLICATION_FACTOR, PSO.eventY * Constants.MULTIPLICATION_FACTOR, 20, 20);
            g.drawLine(PSO.eventX * Constants.MULTIPLICATION_FACTOR, PSO.eventY * Constants.MULTIPLICATION_FACTOR, minx_coord * 5, miny_coord * 5);

            try {
                fillImage2(g, PSO.eventX * Constants.MULTIPLICATION_FACTOR, PSO.eventY * Constants.MULTIPLICATION_FACTOR, 15);
            } catch (IOException ex) {

            }
//                    bw.write(String.valueOf("Event_Location" +"," + "Station_" + x +","+100));
//                    bw.newLine();
        }
    }
    
    
    



    public static Map sortByValue(Map unsortedMap) {
        Map sortedMap = new TreeMap(new ValueComparator(unsortedMap));
        sortedMap.putAll(unsortedMap);
        return sortedMap;
    }

    /**
     * s method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );
    }// </editor-fold>//GEN-END:initComponents

}


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
class ValueComparator implements Comparator {

    Map map;

    public ValueComparator(Map map) {
        this.map = map;
    }

    public int compare(Object keyA, Object keyB) {
        Comparable valueA = (Comparable) map.get(keyA);
        Comparable valueB = (Comparable) map.get(keyB);
        return valueB.compareTo(valueA);
    }

    public static Map sortByValue(Map unsortedMap) {
        Map sortedMap = new TreeMap(new ValueComparator(unsortedMap));
        sortedMap.putAll(unsortedMap);
        return sortedMap;
    }
}
