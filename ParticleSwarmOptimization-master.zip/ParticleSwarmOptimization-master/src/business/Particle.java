package business;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kahma
 */

// Fitness = Probability that the location the particle is on has Event

public class Particle {

    private int xPos;
    private int yPos;
    private double[] cords;
    
    private double xVel;
    private double yVel;
    private double[] velocity;
    private Double crowdSize;
    private Particle localBest;
    private Double temperature;

    public Double getTemperature() {
        return temperature;
    }

    public void setTemperature(Double temperature) {
        this.temperature = temperature;
    }

    public double[] getCords() {
        return cords;
    }

    public void setCords(double[] cords) {
        this.cords = cords;
    }

    public double[] getVelocity() {
        return velocity;
    }

    public void setVelocity(double[] velocity) {
        this.velocity = velocity;
    }

    public double[] getBestLocalPos() {
        return bestLocalPos;
    }

    public void setBestLocalPos(double[] bestLocalPos) {
        this.bestLocalPos = bestLocalPos;
    }

    public double getBestLocalVal() {
        return bestLocalVal;
    }

    public void setBestLocalVal(double bestLocalVal) {
        this.bestLocalVal = bestLocalVal;
    }

    

  private double[] bestLocalPos;
  private double bestLocalVal;
    
    public int getxPos() {
        return xPos;
    }

    public void setxPos(int xPos) {
        this.xPos = xPos;
    }

    public int getyPos() {
        return yPos;
    }

    public void setyPos(int yPos) {
        this.yPos = yPos;
    }

    public double getxVel() {
        return xVel;
    }

    public void setxVel(double xVel) {
        this.xVel = xVel;
    }

    public double getyVel() {
        return yVel;
    }

    public void setyVel(double yVel) {
        this.yVel = yVel;
    }

    public Double getCrowdSize() {
        return crowdSize;
    }

    public void setCrowdSize(Double crowdSize) {
        this.crowdSize = crowdSize;
    }

    public Particle getLocalBest() {
        return localBest;
    }

    public void setLocalBest(Particle localBest) {
        this.localBest = localBest;
    }
    
    public double getFitness(){
        return (crowdSize/Constants.MAX_CROWD + temperature/Constants.temp)*100.0/100.0;
    }
    
}
