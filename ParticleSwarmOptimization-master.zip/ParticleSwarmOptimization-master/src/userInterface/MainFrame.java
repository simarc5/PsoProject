/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package userInterface;

import business.Graph;
import business.Constants;
import static business.Constants.x_coord;
import static business.Constants.y_coord;
import business.Edge;
import business.Events;
import business.Particle;
import static business.SendEmail.sendEmail;
import business.Swarm;
import java.awt.AWTException;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.imageio.ImageIO;
import javax.mail.MessagingException;
import javax.mail.internet.AddressException;
import javax.swing.JOptionPane;
import org.apache.commons.lang3.ArrayUtils;
import org.jfree.ui.RefineryUtilities;
import userInterface.AreaMapJPanel;


/**
 *
 * @author saheb
 */
public class MainFrame extends javax.swing.JFrame {

    private static Swarm swarm;
    private static double[][] areaMap;
    private static Random r = new Random();
    public static int eventX, eventY;
    public static int iteration = 0;
    static AreaMapJPanel map;

   static int[] revisedArrayY;
    static int[] revisedArray;
    static int SrcStation;
    public static double startTime;
    public static double endTime;
    static int linetemp1;
    static int linetemp2;
    Graphics g;
    Boolean bool = false;
    static long start = new Date().getTime();
    static HashMap<Integer,Double> particleGbest = new HashMap<Integer,Double>();
    static HashMap<Integer,Double> iterationGbest = new HashMap<Integer,Double>();
    boolean flag = true;
    ArrayList<String> arrli = new ArrayList<String>();
    
    public MainFrame() throws IOException {
        initComponents();

    }

    public void initializeCrowd() {
        areaMap = new double[Constants.AREA_SIZE][Constants.AREA_SIZE];
        for (int i = 0; i < Constants.AREA_SIZE; i++) {
            for (int j = 0; j < Constants.AREA_SIZE; j++) {
                areaMap[i][j] = 100.0 + r.nextDouble() * 100.0;
            }
        }
    }

    public static void initializeEventPoint() {
        eventX = Constants.AREA_SIZE / 4 + r.nextInt(Constants.AREA_SIZE / 2);
        eventY = Constants.AREA_SIZE / 4 + r.nextInt(Constants.AREA_SIZE / 2);
        System.out.println("Event-location on map (" + eventX + "," + eventY + ")");
        displayEventPointOnMap();
    }

    public static void displayEventPointOnMap() {
        for (int i = 3; i >= 0; i--) {
            updateMapPosition(i, Constants.MAX_CROWD - (i * Constants.CROWD_DIFF));         
        }
        areaMap[eventX][eventY] = Constants.CROWD_DIFF;
    }

    public static void evaluateCrowd() {
        for (Particle p : swarm.getParticles()) {
            p.setCrowdSize(areaMap[p.getxPos()][p.getyPos()]);
            p.setTemperature(areaMap[p.getxPos()][p.getyPos()]);
        }
    }

    public static void getGlobalBest() {
        Particle best = swarm.getGlobalBest();
        for (Particle p : swarm.getParticles()) {
            if (p.getFitness() > best.getFitness()) {
                best = p;
                
                
            }
            
        }
        swarm.setGlobalBest(best);
        
       //    System.out.println("Particle g best" + particleGbest);

    }

    public void psoItertation() {

        Timer timer = new Timer();
        timer.schedule(new TimerTask() {

            @Override
            public void run() {
                Boolean changed = false;
                startTime = System.currentTimeMillis();
                while (iteration < Constants.MAX_ITERATION && !changed) {
                    try {
                        Thread.sleep(Constants.THREAD_SLEEP_TIME);
                        changed = true;

                        // Fitness function evalutaion at new location
                        evaluateCrowd();

                        // Get global best Value
                        getGlobalBest();

                        // Update the new Postion
                        updatePosition(iteration);

                        // animating for new positions
                        map.repaint();
                        
                        
                        iterationGbest.put(iteration, swarm.getGlobalBest().getFitness());

                        // Checking if all particles have reached goal
                        for (Particle p : swarm.getParticles()) {
                            
                                    particleGbest.put(iteration,p.getLocalBest().getFitness());
                            if (p.getLocalBest().getFitness() != swarm.getGlobalBest().getFitness()) {
                                changed = false;
                                break;
                            
                            } 
                        }

                        System.out.println("Iteration " + iteration++ + " -> best location detected by swarm (" + swarm.getGlobalBest().getxPos() + "," + swarm.getGlobalBest().getyPos() + ")" +"Fitness value" + swarm.getGlobalBest().getFitness());
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                }
                endTime = System.currentTimeMillis();
                System.out.println("\n\nAll particles at Station in iteration " + iteration + " -> Total Time taken: " + (endTime - startTime) / 1000 + " seconds");

                timer.cancel();

            }
        }, 0, 1);
    }

    public void updatePosition(int iteration) {
        Particle gBest = swarm.getGlobalBest();
        double w = Constants.INERTIA_WEIGHT - (((double) iteration) / Constants.MAX_ITERATION) * (Constants.INERTIA_WEIGHT);

        synchronized (this) {
            for (Particle p : swarm.getParticles()) {
                double r1 = r.nextDouble();
                double r2 = r.nextDouble();

                // new x & y velocities
                int newX = (int) ((w * p.getxVel())
                        + (r1 * Constants.C1) * (p.getLocalBest().getxPos() - p.getxPos())
                        + (r2 * Constants.C2) * (gBest.getxPos() - p.getxPos()));

                int newY = (int) ((w * p.getyVel())
                        + (r1 * Constants.C1) * (p.getLocalBest().getyPos() - p.getyPos())
                        + (r2 * Constants.C2) * (gBest.getyPos() - p.getyPos()));

                // Limiting new velocities to range
                if (newX < Constants.MAX_V_CHANGE * -1) {
                    newX = (int) Constants.MAX_V_CHANGE * -1;
                }

                if (newY < Constants.MAX_V_CHANGE * -1) {
                    newY = (int) Constants.MAX_V_CHANGE * -1;
                }

                if (newX > Constants.MAX_V_CHANGE) {
                    newX = (int) Constants.MAX_V_CHANGE;
                }

                if (newY > Constants.MAX_V_CHANGE) {
                    newY = (int) Constants.MAX_V_CHANGE;
                }

//            System.out.println("new velocities "+newX + " " + newY);
                p.setxVel(newX);
                p.setyVel(newY);

                // Updating positions
                if (p.getxPos() + newX > Constants.AREA_SIZE - 1) {
                    p.setxPos(Constants.AREA_SIZE - 1);
                } else if (p.getxPos() + newX < 0) {
                    p.setxPos(0);
                } else {
                    p.setxPos(p.getxPos() + newX);
                }

                if (p.getyPos() + newY > Constants.AREA_SIZE - 1) {
                    p.setyPos(Constants.AREA_SIZE - 1);
                } else if (p.getyPos() + newY < 0) {
                    p.setyPos(0);
                } else {
                    p.setyPos(p.getyPos() + newY);
                }
            }
        }
    }

    public static void printParticleData() {
        for (Particle p : swarm.getParticles()) {
            System.out.println("(" + p.getxPos() + "," + p.getyPos() + ") -> (" + p.getxVel() + "," + p.getyVel() + ") -> " + p.getCrowdSize()+ " -> " + p.getFitness());
        }
    }

    private static void updateMapPosition(int range, double temp) {
        int xStart = (eventX - range < 0) ? 0 : eventX - range;
        int yStart = (eventY - range < 0) ? 0 : eventY - range;
        for (int i = xStart; i < eventX + range + 1 && i < Constants.AREA_SIZE; i++) {
            for (int j = yStart; j < eventY + range + 1 && j < Constants.AREA_SIZE; j++) {
                areaMap[i][j] = temp;
            }
        }
    }

    public void printMap() {
        for (int i = 0; i < Constants.AREA_SIZE; i++) {
            System.out.println("");
            for (int j = 0; j < Constants.AREA_SIZE; j++) {
                System.out.print(Math.round(areaMap[i][j] * 100.0) / 100.0 + " ");
            }
        }
    }

    public static void initializeParticles() {
        Particle p;
        for (int i = 0; i < Constants.SWARM_SIZE; i++) {
            p = new Particle();

            int xPos = r.nextInt(Constants.AREA_SIZE);
            int yPos = r.nextInt(Constants.AREA_SIZE);

            p.setxPos(xPos);
            p.setyPos(yPos);

            double xVel = r.nextDouble() * Constants.MAX_V_CHANGE;
            double yVel = r.nextDouble() * Constants.MAX_V_CHANGE;

            p.setxVel(xVel);
            p.setyVel(yVel);

            p.setLocalBest(p);

            swarm.addParticle(p);
        }

        evaluateCrowd();
        // Initialize first particle as global best
        swarm.setGlobalBest(swarm.getParticles().get(0));
        
    }

    public void psoDisplay() {

        // Initialize the particles
        initializeParticles();

        map = new AreaMapJPanel(eventX, eventY, swarm, areaMap);
        psoItertation();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")

    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        splitPane = new javax.swing.JSplitPane();
        leftPanel = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        swarmText = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        stationText = new javax.swing.JTextField();
        optimizeBtn = new javax.swing.JButton();
        emailBtn = new javax.swing.JButton();
        submitBtn = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        iterationTxt = new javax.swing.JTextField();
        errLabel = new javax.swing.JLabel();
        pathLabel = new javax.swing.JLabel();
        emailLbl = new javax.swing.JLabel();
        graphBtn = new javax.swing.JButton();
        drawBtn = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();
        srcStationTxt = new javax.swing.JTextField();
        rightPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        splitPane.setOrientation(javax.swing.JSplitPane.VERTICAL_SPLIT);

        leftPanel.setBackground(new java.awt.Color(51, 153, 255));

        jLabel1.setText("Enter number Of Swarm Particle :");

        swarmText.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                swarmTextActionPerformed(evt);
            }
        });
        swarmText.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyPressed(java.awt.event.KeyEvent evt) {
                swarmTextKeyPressed(evt);
            }
            public void keyReleased(java.awt.event.KeyEvent evt) {
                swarmTextKeyReleased(evt);
            }
        });

        jLabel2.setText("Enter number Of Stations :");

        stationText.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                stationTextKeyReleased(evt);
            }
        });

        optimizeBtn.setText("Calculate Path");
        optimizeBtn.setEnabled(false);
        optimizeBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                optimizeBtnActionPerformed(evt);
            }
        });

        emailBtn.setText("Send Email");
        emailBtn.setEnabled(false);
        emailBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                emailBtnActionPerformed(evt);
            }
        });

        submitBtn.setText("Submit");
        submitBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitBtnActionPerformed(evt);
            }
        });

        jLabel3.setText("Enter number Of Iterations:");

        iterationTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                iterationTxtActionPerformed(evt);
            }
        });
        iterationTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                iterationTxtKeyReleased(evt);
            }
        });

        graphBtn.setText("Graph");
        graphBtn.setEnabled(false);
        graphBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                graphBtnActionPerformed(evt);
            }
        });

        drawBtn.setText("Draw Path");
        drawBtn.setEnabled(false);
        drawBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                drawBtnActionPerformed(evt);
            }
        });

        jLabel4.setText("Enter Source Station :");

        srcStationTxt.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                srcStationTxtActionPerformed(evt);
            }
        });
        srcStationTxt.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                srcStationTxtKeyReleased(evt);
            }
        });

        javax.swing.GroupLayout leftPanelLayout = new javax.swing.GroupLayout(leftPanel);
        leftPanel.setLayout(leftPanelLayout);
        leftPanelLayout.setHorizontalGroup(
            leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftPanelLayout.createSequentialGroup()
                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(iterationTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(srcStationTxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(swarmText, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 206, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(stationText, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(32, 32, 32)
                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(optimizeBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(leftPanelLayout.createSequentialGroup()
                                .addComponent(submitBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 134, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(30, 30, 30)
                                .addComponent(pathLabel)
                                .addGap(11, 11, 11)
                                .addComponent(errLabel)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addComponent(drawBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 133, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(emailLbl)
                        .addGap(51, 51, 51)))
                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(emailBtn, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(graphBtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(467, Short.MAX_VALUE))
        );
        leftPanelLayout.setVerticalGroup(
            leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(leftPanelLayout.createSequentialGroup()
                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addGap(15, 15, 15)
                        .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(swarmText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(jLabel1))
                            .addGroup(leftPanelLayout.createSequentialGroup()
                                .addGap(10, 10, 10)
                                .addComponent(errLabel)))
                        .addGap(5, 5, 5)
                        .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(leftPanelLayout.createSequentialGroup()
                                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(leftPanelLayout.createSequentialGroup()
                                        .addGap(8, 8, 8)
                                        .addComponent(pathLabel))
                                    .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(stationText, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel2)))
                                .addGroup(leftPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(leftPanelLayout.createSequentialGroup()
                                        .addGap(52, 52, 52)
                                        .addComponent(emailLbl))
                                    .addGroup(leftPanelLayout.createSequentialGroup()
                                        .addGap(6, 6, 6)
                                        .addComponent(iterationTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(srcStationTxt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addGroup(leftPanelLayout.createSequentialGroup()
                                .addGap(38, 38, 38)
                                .addComponent(jLabel3)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jLabel4))))
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addComponent(graphBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(emailBtn))
                    .addGroup(leftPanelLayout.createSequentialGroup()
                        .addGap(27, 27, 27)
                        .addComponent(submitBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(optimizeBtn)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(drawBtn)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        splitPane.setTopComponent(leftPanel);

        javax.swing.GroupLayout rightPanelLayout = new javax.swing.GroupLayout(rightPanel);
        rightPanel.setLayout(rightPanelLayout);
        rightPanelLayout.setHorizontalGroup(
            rightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 1125, Short.MAX_VALUE)
        );
        rightPanelLayout.setVerticalGroup(
            rightPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 623, Short.MAX_VALUE)
        );

        splitPane.setRightComponent(rightPanel);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(splitPane)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(splitPane)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void srcStationTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_srcStationTxtKeyReleased
        // TODO add your handling code here:


try{
    String PATTERN = "^[0-9]{1,2}$";

        Pattern patt= Pattern.compile(PATTERN);
        Matcher match = patt.matcher(srcStationTxt.getText());
        if(!match.matches())
        {
            JOptionPane.showMessageDialog(rootPane, "Only Numbers Allowed");
        }
        if(srcStationTxt.getText().equals("0"))
        {
            JOptionPane.showMessageDialog(rootPane, "Please enter valid input!");
        }
        
        int station = Integer.parseInt(stationText.getText());
        
              SrcStation = Integer.valueOf(srcStationTxt.getText());
        
              if(!srcStationTxt.getText().equals("")){
        
              if(SrcStation > station){
                   JOptionPane.showMessageDialog(rootPane, "Please enter vaid station number!");
              }
              }
}
catch(Exception e){
    JOptionPane.showMessageDialog(rootPane, "Please enter valid number");
}
    }//GEN-LAST:event_srcStationTxtKeyReleased

    private void srcStationTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_srcStationTxtActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_srcStationTxtActionPerformed

    private void drawBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_drawBtnActionPerformed
        // TODO add your handling code here:

        String mydata=null;
        String coordOut = "";

        for (int i=0; i<map.path.size(); i++)
        {
            System.out.println("Path: "+map.path.get(i));
            mydata = mydata+map.path.get(i);

        }
        Pattern pattern = Pattern.compile("\\((.*?)\\)");
        Matcher matcher = matcher = pattern.matcher(mydata);
        while (matcher.find())
        {
            coordOut = coordOut+matcher.group(1)+",";
        }

        String[] p = coordOut.split(",");
        int[] xCoord = new int[p.length];
        int[] yCoord = new int[p.length];
        for (int i = 0; i < p.length; i++) {

            if(i==0||i%2==0)
            {
                xCoord[i] = Integer.parseInt(p[i]);
                yCoord[i] = Integer.parseInt("9999");
            }
            else
            {
                yCoord[i] = Integer.parseInt(p[i]);
                xCoord[i] = Integer.parseInt("9999");
            }

        }

   

        xCoord = ArrayUtils.removeElement(xCoord, 9999);
        int key = 9999;
        xCoord = removeElements(xCoord, key);
        yCoord = removeElements(yCoord, key);


        List<Integer> lstX = new ArrayList<Integer>();

        lstX.add(xCoord[0]);

        for(int i=1;i<xCoord.length;i++)
        {
            if(xCoord[i]!=lstX.get(lstX.size()-1)) lstX.add(xCoord[i]);
        }

        int lstSize = lstX.size();
        revisedArray = new int[lstSize];
        for(int i = 0; i < lstSize; i++) revisedArray[i] = lstX.get(i);


        List<Integer> lstY = new ArrayList<Integer>();

        lstY.add(yCoord[0]);

        for(int i=1;i<yCoord.length;i++)
        {
            if(yCoord[i]!=lstY.get(lstY.size()-1)) lstY.add(yCoord[i]);
        }

        int lstSizeY = lstY.size();
        revisedArrayY = new int[lstSizeY];
        for(int i = 0; i < lstSizeY; i++) revisedArrayY[i] = lstY.get(i);

        Constants.flag=true;
        repaint();
        emailBtn.setEnabled(true);
        graphBtn.setEnabled(true);

        }

        public static void draw2(Graphics g){
            Graphics2D g2 = (Graphics2D) g;
            g.setColor(Color.RED);

            for(int i=0;i<revisedArray.length-1;i++)
            {
                if(i!=0)
                {
                    g.drawLine(linetemp1*5, linetemp2*5, revisedArray[i]*5, revisedArrayY[i]*5);
            
                    g2.setStroke(new BasicStroke(4));
                }
                linetemp1 = revisedArray[i];
                linetemp2 = revisedArrayY[i];

            }
    }//GEN-LAST:event_drawBtnActionPerformed

    private void graphBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_graphBtnActionPerformed
        // TODO add your handling code here:

        Graph ll = new Graph("Iteration", "Particle Pbest", particleGbest);
        ll.pack( );
        RefineryUtilities.centerFrameOnScreen( ll );
        ll.setVisible( true );

        Graph lll = new Graph("Iteration", "Swarm Gbest", iterationGbest);
        lll.pack( );
        RefineryUtilities.centerFrameOnScreen( lll );
        lll.setVisible( true );
    }//GEN-LAST:event_graphBtnActionPerformed

    private void iterationTxtKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_iterationTxtKeyReleased
        // TODO add your handling code here:

        try{
        String PATTERN = "^[0-9]{1,2}$";

        Pattern patt= Pattern.compile(PATTERN);
        Matcher match = patt.matcher(iterationTxt.getText());
        if(!match.matches())
        {
            JOptionPane.showMessageDialog(rootPane, "Only Numbers Allowed");
        }
        }
        catch(Exception e){
            JOptionPane.showMessageDialog(rootPane, "Enter valid number");
        }
       
    }//GEN-LAST:event_iterationTxtKeyReleased

    private void iterationTxtActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_iterationTxtActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_iterationTxtActionPerformed

    private void submitBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitBtnActionPerformed
        // TODO add your handling code here:

        if(!(swarmText.getText().equals("")||stationText.getText().equals("") ||iterationTxt.getText().equals("") ||swarmText.getText().equals("0")||stationText.getText().equals("0")||iterationTxt.getText().equals("")||srcStationTxt.getText().equals("")))
        {

            errLabel.setText("");
            Constants.SWARM_SIZE = Integer.parseInt(swarmText.getText().toString());
            Constants.TOTAL_TStations = Integer.parseInt(stationText.getText().toString());
            Constants.MAX_ITERATION = Integer.parseInt(iterationTxt.getText().toString());

            int low = 15;
            int high = 250;
            for (int i = 0; i < Constants.TOTAL_TStations; i++) {
                x_coord[i] = r.nextInt(high) + 2 * low;
                y_coord[i] = r.nextInt(high - 6 * low) + low;
            }
            swarm = new Swarm();
            initializeCrowd();
            initializeEventPoint();
            psoDisplay();
            splitPane.setRightComponent(map);

            setVisible(true);
            optimizeBtn.setEnabled(true);
            emailBtn.setEnabled(false);
            graphBtn.setEnabled(false);

        }
        else {
            errLabel.setText("All field are mandatory!");

        }
    }//GEN-LAST:event_submitBtnActionPerformed

    private void emailBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_emailBtnActionPerformed
        // TODO add your handling code here:

        try {
            Thread.sleep(1000);
            Robot r = new Robot();

            // It saves screenshot to desired path
            //            String path = "/Users/saheb/Desktop/Shot.jpg";
            String path = "C:\\Users\\kahma\\OneDrive\\Desktop\\Shot.jpg";

            // Used to get ScreenSize and capture image
            Rectangle capture =
            new Rectangle(Toolkit.getDefaultToolkit().getScreenSize());
            BufferedImage Image = r.createScreenCapture(capture);
            ImageIO.write(Image, "jpg", new File(path));
            System.out.println("Screenshot saved");
        }
        catch (AWTException | IOException | InterruptedException ex) {
            System.out.println(ex);
        }

        try {
            sendEmail();
        } catch (AddressException ex) {
            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MessagingException ex) {
            Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
        }

        System.out.println("Email Sent Successfully...");

        emailLbl.setText("Email sent");

    }//GEN-LAST:event_emailBtnActionPerformed

    private void optimizeBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_optimizeBtnActionPerformed
        // TODO add your handling code here:
        if(!srcStationTxt.getText().equals("")){
            errLabel.setText("");
            SrcStation = Integer.valueOf(srcStationTxt.getText());
            LinkedList<Events> eventsTask = new LinkedList<Events>();
            for (int i = 1; i <= 2; i++) {
                eventsTask.add(new Events());
            }
            int processors = Runtime.getRuntime().availableProcessors();
            ExecutorService taskPool = Executors.newFixedThreadPool(processors);
            List<Future<List<Edge>>> futureResults = new LinkedList<Future<List<Edge>>>();
            //        List<Edge> result = null;
            try {
                futureResults = taskPool.invokeAll(eventsTask);
            } catch (InterruptedException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }

            taskPool.shutdown();
            //Traversing through all future list and see whose mark one as result who returns list of directions
            for (Future<List<Edge>> edges : futureResults) {
                try {
                    if (edges.get() != null) {
                        System.out.println("Path_From_Thread "+ edges.get().toString());
                        arrli.add(edges.get().toString());
                    }
                } catch (InterruptedException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                } catch (ExecutionException ex) {
                    Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

            pathLabel.setText("Shortest Path Calculated");

            drawBtn.setEnabled(true);
        }

        else

        {
            errLabel.setText("All field are mandatory!");

        }

    }//GEN-LAST:event_optimizeBtnActionPerformed

    private void stationTextKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_stationTextKeyReleased
        // TODO add your handling code here:
        
        try{
        String PATTERN = "^[0-9]{1,4}$";

        Pattern patt= Pattern.compile(PATTERN);
        Matcher match = patt.matcher(stationText.getText());
        if(!match.matches())
        {
            JOptionPane.showMessageDialog(rootPane, "Only Numbers Allowed");
        }
      
        }
        catch(Exception e){
             JOptionPane.showMessageDialog(rootPane, "Enter a valid number!");
        }

    }//GEN-LAST:event_stationTextKeyReleased

    private void swarmTextKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_swarmTextKeyReleased
        // TODO add your handling code here:
       
        
        try
        {String PATTERN = "^[0-9]{1,4}$";

        Pattern patt= Pattern.compile(PATTERN);
        Matcher match = patt.matcher(swarmText.getText());
        if(!match.matches())
        {
            JOptionPane.showMessageDialog(rootPane, "Only Numbers Allowed");
        }
        }
       catch(Exception e){
             JOptionPane.showMessageDialog(rootPane, "Enter a valid number!");
        }

    }//GEN-LAST:event_swarmTextKeyReleased

    private void swarmTextKeyPressed(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_swarmTextKeyPressed
        // TODO add your handling code here:
    }//GEN-LAST:event_swarmTextKeyPressed

    private void swarmTextActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_swarmTextActionPerformed
        // TODO add your handling code here:

    }//GEN-LAST:event_swarmTextActionPerformed

    public static synchronized List<Edge> eventSearch() throws IOException {



        String startCity = "Station_"+SrcStation;
        String endCity = "Event_Location";
        return map.sourceToDest(startCity, endCity);
        
    }

    
      public static int[] removeElements(int[] arr, int key) 
    { 
          // Move all other elements to beginning  
          int index = 0; 
          for (int i=0; i<arr.length; i++) 
             if (arr[i] != key) 
                arr[index++] = arr[i]; 
  
         // Create a copy of arr[]  
         return Arrays.copyOf(arr, index); 
    } 
    
    /**
     * @param input
     * @param args the command line arguments
     * @return 
     */
    
  public static ArrayList<Integer> noConsecutiveDups(ArrayList<Integer> input) {

  ArrayList<Integer> newList = new ArrayList<Integer>();

  // Always add first value
  newList.add(input.get(0));

  // Iterate the remaining values
  for(int i = 1; i < input.size(); i++) {
    // Compare current value to previous
    if(input.get(i-1) != input.get(i)) {
       newList.add(input.get(i));
    }
  }

  return newList;
    }
    /**
     * @param args the command line arguments
     */
    

    
    
    public static void main(String args[]) {

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            MainFrame mf;
            try {
                mf = new MainFrame();
                mf.setVisible(true);
            } catch (IOException ex) {
                Logger.getLogger(MainFrame.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
    }


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton drawBtn;
    private javax.swing.JButton emailBtn;
    private javax.swing.JLabel emailLbl;
    private javax.swing.JLabel errLabel;
    private javax.swing.JButton graphBtn;
    private javax.swing.JTextField iterationTxt;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel leftPanel;
    private javax.swing.JButton optimizeBtn;
    private javax.swing.JLabel pathLabel;
    private javax.swing.JPanel rightPanel;
    private javax.swing.JSplitPane splitPane;
    private javax.swing.JTextField srcStationTxt;
    private javax.swing.JTextField stationText;
    private javax.swing.JButton submitBtn;
    private javax.swing.JTextField swarmText;
    // End of variables declaration//GEN-END:variables
}
